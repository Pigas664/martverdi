document.addEventListener("DOMContentLoaded", function () {

    // Ao abrir o site em uma nova sessão/aba, o cliente começa deslogado.
    // A sessão permanece disponível enquanto esta aba do site estiver aberta.
    if (!sessionStorage.getItem("martverdiSessao")) {
        localStorage.removeItem("usuarioLogado");
        sessionStorage.setItem("martverdiSessao", "1");
    }

    const usuarioSalvo = localStorage.getItem("usuarioLogado");
    const usuarioTopo = document.getElementById("usuarioTopo");
    const mensagemLogin = document.getElementById("mensagemLogin");

    const contaLinks = document.querySelectorAll('.usuario-topo, #topMinhaConta');
    if (usuarioSalvo) {
        if (usuarioTopo) usuarioTopo.textContent = usuarioSalvo;
        contaLinks.forEach(function (link) { link.href = './pages/painel.html'; });

        if (mensagemLogin) {
            mensagemLogin.textContent = "Você está logado como " + usuarioSalvo;
            mensagemLogin.style.color = "green";
        }
    }

    // CATÁLOGO DE ALIMENTOS + BUSCA + FILTROS
    const campoBusca = document.getElementById("campoBusca");
    const resultadoBusca = document.getElementById("resultadoBusca");
    const alimentosGrid = document.getElementById("alimentosGrid");
    const alimentosVazio = document.getElementById("alimentosVazio");
    const resultadoQuantidade = document.getElementById("resultadoQuantidade");
    const resultadoFiltroTexto = document.getElementById("resultadoFiltroTexto");
    const alimentosTotal = document.getElementById("alimentosTotal");
    const ordenarProdutos = document.getElementById("ordenarProdutos");
    const precoMin = document.getElementById("precoMin");
    const precoMax = document.getElementById("precoMax");
    const chips = document.querySelectorAll(".categoria-chip");
    const filtrosCategoria = document.querySelectorAll(".filtro-categoria");
    let catalogoProdutos = [];
    let categoriaAtiva = "Todos";

    const iconesCategoria = {
        "Mercearia": "fa-basket-shopping",
        "Laticínios": "fa-cheese",
        "Bebidas": "fa-bottle-water",
        "Bebidas Alcoólicas": "fa-wine-bottle",
        "Açougue": "fa-drumstick-bite",
        "Biscoitos e Doces": "fa-cookie-bite",
        "Padaria": "fa-bread-slice",
        "Congelados": "fa-snowflake",
        "Limpeza": "fa-pump-soap",
        "Higiene Pessoal": "fa-pump-soap",
        "Cuidados Pessoais": "fa-pump-soap",
        "Frios e Laticínios": "fa-cheese",
        "Frios e Embutidos": "fa-drumstick-bite",
        "Molhos e Condimentos": "fa-bottle-droplet"
    };

    function moeda(valor) {
        return valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
    }

    function imagemProduto(produto) {
        if (produto.imagem) {
            return `<img src="${produto.imagem}" alt="${produto.nome}" loading="lazy">`;
        }
        const icone = iconesCategoria[produto.categoria] || "fa-basket-shopping";
        return `<div class="produto-visual-placeholder"><i class="fa-solid ${icone}"></i><span>${produto.categoria}</span></div>`;
    }

    function criarCardProduto(produto) {
        return `
            <article class="produto-card" data-id="${produto.id}">
                <div class="produto-imagem">
                    ${produto.oferta ? '<span class="produto-badge">OFERTA</span>' : ''}
                    ${imagemProduto(produto)}
                </div>
                <div class="produto-info">
                    <h3>${produto.nome}</h3>
                    <small class="produto-marca">${produto.marca}</small>
                    <div class="stars">★★★★★</div>
                    <span class="preco-produto">${moeda(produto.preco)}</span>
                    <button class="btn-carrinho" data-id="${produto.id}">Adicionar ao Carrinho</button>
                </div>
            </article>
        `;
    }

    function aplicarCatalogo() {
        if (!alimentosGrid) return;

        const termo = campoBusca ? campoBusca.value.toLowerCase().trim() : "";
        const selecionadas = Array.from(filtrosCategoria).filter(function (f) { return f.checked; }).map(function (f) { return f.value; });
        const minimo = precoMin && precoMin.value !== "" ? Number(precoMin.value) : 0;
        const maximo = precoMax && precoMax.value !== "" ? Number(precoMax.value) : Infinity;

        let filtrados = catalogoProdutos.filter(function (produto) {
            const texto = `${produto.nome} ${produto.marca} ${produto.categoria}`.toLowerCase();
            const categoriaOk = categoriaAtiva === "Todos" || produto.categoria === categoriaAtiva;
            const grupoOk = selecionadas.length === 0 || selecionadas.includes(produto.categoria);
            const precoOk = produto.preco >= minimo && produto.preco <= maximo;
            return categoriaOk && grupoOk && precoOk && texto.includes(termo);
        });

        if (ordenarProdutos) {
            const ordem = ordenarProdutos.value;
            filtrados.sort(function (a, b) {
                if (ordem === "menor-preco") return a.preco - b.preco;
                if (ordem === "maior-preco") return b.preco - a.preco;
                if (ordem === "az") return a.nome.localeCompare(b.nome, "pt-BR");
                return a.id - b.id;
            });
        }

        alimentosGrid.innerHTML = filtrados.map(criarCardProduto).join("");
        if (alimentosVazio) alimentosVazio.hidden = filtrados.length !== 0;
        if (resultadoQuantidade) resultadoQuantidade.textContent = `${filtrados.length} ${filtrados.length === 1 ? "produto" : "produtos"}`;
        if (alimentosTotal) alimentosTotal.textContent = `${catalogoProdutos.length} produtos`;
        if (resultadoFiltroTexto) resultadoFiltroTexto.textContent = categoriaAtiva === "Todos" ? " em todas as categorias" : ` em ${categoriaAtiva}`;

        adicionarBotoesCarrinho(alimentosGrid.querySelectorAll(".btn-carrinho"));
    }

    function mostrarSugestoesBusca() {
        if (!campoBusca || !resultadoBusca) return;
        const termo = campoBusca.value.toLowerCase().trim();
        if (!termo) {
            resultadoBusca.style.display = "none";
            return;
        }
        const encontrados = catalogoProdutos.filter(function (produto) {
            return `${produto.nome} ${produto.marca} ${produto.categoria}`.toLowerCase().includes(termo);
        }).slice(0, 6);

        resultadoBusca.innerHTML = encontrados.length ? encontrados.map(function (produto) {
            return `<div class="item-resultado"><div class="item-resultado-icone"><i class="fa-solid ${iconesCategoria[produto.categoria] || "fa-basket-shopping"}"></i></div><div><h4>${produto.nome}</h4><span>${moeda(produto.preco)}</span></div></div>`;
        }).join("") : `<div class="item-resultado"><div><h4>Nenhum produto encontrado</h4><span>Tente outro termo.</span></div></div>`;
        resultadoBusca.style.display = "block";
    }

    if (campoBusca) {
        campoBusca.addEventListener("input", function () {
            aplicarCatalogo();
            mostrarSugestoesBusca();
        });
    }

    chips.forEach(function (chip) {
        chip.addEventListener("click", function () {
            categoriaAtiva = chip.dataset.categoria;
            chips.forEach(function (item) { item.classList.remove("active"); });
            chip.classList.add("active");
            filtrosCategoria.forEach(function (filtro) { filtro.checked = categoriaAtiva !== "Todos" && filtro.value === categoriaAtiva; });
            aplicarCatalogo();
        });
    });

    filtrosCategoria.forEach(function (filtro) {
        filtro.addEventListener("change", function () {
            const selecionadas = Array.from(filtrosCategoria).filter(function (f) { return f.checked; });
            categoriaAtiva = selecionadas.length === 1 ? selecionadas[0].value : "Todos";
            chips.forEach(function (chip) { chip.classList.toggle("active", chip.dataset.categoria === categoriaAtiva); });
            if (selecionadas.length !== 1) chips[0]?.classList.add("active");
            aplicarCatalogo();
        });
    });

    [precoMin, precoMax].forEach(function (input) {
        input?.addEventListener("input", aplicarCatalogo);
    });
    ordenarProdutos?.addEventListener("change", aplicarCatalogo);

    document.getElementById("limparFiltros")?.addEventListener("click", function () {
        categoriaAtiva = "Todos";
        filtrosCategoria.forEach(function (f) { f.checked = false; });
        if (precoMin) precoMin.value = "";
        if (precoMax) precoMax.value = "";
        if (campoBusca) campoBusca.value = "";
        chips.forEach(function (chip, i) { chip.classList.toggle("active", i === 0); });
        if (resultadoBusca) resultadoBusca.style.display = "none";
        aplicarCatalogo();
    });

    document.querySelector(".categoria-scroll-prev")?.addEventListener("click", function () {
        document.getElementById("alimentosCategorias")?.scrollBy({ left: -280, behavior: "smooth" });
    });
    document.querySelector(".categoria-scroll-next")?.addEventListener("click", function () {
        document.getElementById("alimentosCategorias")?.scrollBy({ left: 280, behavior: "smooth" });
    });

    fetch("./data/produtos.json")
        .then(function (resposta) { if (!resposta.ok) throw new Error("Não foi possível carregar o catálogo."); return resposta.json(); })
        .then(function (dados) {
            catalogoProdutos = dados;
            aplicarCatalogo();
        })
        .catch(function (erro) {
            console.error(erro);
            if (alimentosVazio) {
                alimentosVazio.hidden = false;
                alimentosVazio.querySelector("h3").textContent = "Não foi possível carregar os produtos";
            }
        });

    // CARRINHO
    let carrinhoItens = JSON.parse(localStorage.getItem("carrinhoItens")) || [];
    const contador = document.getElementById("contadorCarrinho");
    const toast = document.getElementById("toast");

    if (contador) contador.textContent = carrinhoItens.length;

    const pendenteInicial = localStorage.getItem("martverdiProdutoPendente");
    if (pendenteInicial && localStorage.getItem("usuarioLogado")) {
        try {
            const itemPendente = JSON.parse(pendenteInicial);
            carrinhoItens.push(itemPendente);
            localStorage.setItem("carrinhoItens", JSON.stringify(carrinhoItens));
            localStorage.setItem("carrinho", carrinhoItens.length);
            if (contador) contador.textContent = carrinhoItens.length;
            localStorage.removeItem("martverdiProdutoPendente");
            if (toast) { toast.classList.add("mostrar"); setTimeout(function(){ toast.classList.remove("mostrar"); }, 2200); }
        } catch(e) { localStorage.removeItem("martverdiProdutoPendente"); }
    }

    function adicionarBotoesCarrinho(botoes) {
        botoes.forEach(function (botao) {
            if (botao.dataset.cartBound === "1") return;
            botao.dataset.cartBound = "1";
            botao.addEventListener("click", function () {
                const card = botao.closest(".produto-card");
                const nome = card.querySelector("h3").textContent;
                const preco = card.querySelector(".preco-produto, .produto-info span").textContent;
                const imagemElemento = card.querySelector("img");
                const imagem = imagemElemento ? imagemElemento.src : "";
                const item = { nome, preco, imagem };

                if (!localStorage.getItem("usuarioLogado")) {
                    localStorage.setItem("martverdiProdutoPendente", JSON.stringify(item));
                    localStorage.setItem("martverdiDestinoLogin", window.location.href);
                    window.location.href = "./pages/login.html";
                    return;
                }

                carrinhoItens.push(item);
                localStorage.setItem("carrinhoItens", JSON.stringify(carrinhoItens));
                localStorage.setItem("carrinho", carrinhoItens.length);
                if (contador) contador.textContent = carrinhoItens.length;

                if (toast) {
                    toast.classList.add("mostrar");
                    setTimeout(function () { toast.classList.remove("mostrar"); }, 2000);
                }
            });
        });
    }

    adicionarBotoesCarrinho(document.querySelectorAll(".btn-carrinho"));

    // CEP / ENTREGA
    const abrirCep = document.getElementById("abrirCep");
    const cepModal = document.getElementById("cepModal");
    const cepInput = document.getElementById("cepInput");
    const cepTexto = document.getElementById("cepTexto");
    const cepMensagem = document.getElementById("cepMensagem");
    const cepSalvo = localStorage.getItem("martverdiCep") || "";

    function formatarCep(valor) {
        const numeros = valor.replace(/\D/g, "").slice(0, 8);
        return numeros.length > 5 ? numeros.slice(0,5) + "-" + numeros.slice(5) : numeros;
    }
    function atualizarCepTopo() {
        const atual = localStorage.getItem("martverdiCep") || "";
        if (cepTexto) cepTexto.textContent = atual ? "CEP: " + atual : "Informe seu CEP";
    }
    atualizarCepTopo();
    if (abrirCep) abrirCep.addEventListener("click", function () {
        if (!cepModal) return;
        cepModal.hidden = false;
        if (cepInput) { cepInput.value = localStorage.getItem("martverdiCep") || ""; cepInput.focus(); }
    });
    cepInput?.addEventListener("input", function () { cepInput.value = formatarCep(cepInput.value); });
    document.querySelectorAll("[data-fechar-cep]").forEach(function (el) {
        el.addEventListener("click", function () { if (cepModal) cepModal.hidden = true; });
    });
    document.getElementById("salvarCep")?.addEventListener("click", function () {
        const valor = formatarCep(cepInput?.value || "");
        if (valor.length !== 9) { if (cepMensagem) { cepMensagem.textContent = "Digite um CEP válido com 8 números."; cepMensagem.style.color = "#C62828"; } return; }
        localStorage.setItem("martverdiCep", valor);
        const usuarioAtual = localStorage.getItem("usuarioLogado");
        const usuarios = JSON.parse(localStorage.getItem("martverdiUsuarios") || "[]");
        const usuarioObj = usuarios.find(function (u) { return u.usuario === usuarioAtual; });
        if (usuarioObj) { usuarioObj.cep = valor; localStorage.setItem("martverdiUsuarios", JSON.stringify(usuarios)); }
        atualizarCepTopo();
        if (cepMensagem) { cepMensagem.textContent = "CEP salvo com sucesso!"; cepMensagem.style.color = "#2D6A4F"; }
        setTimeout(function () { if (cepModal) cepModal.hidden = true; }, 600);
    });

    // CARROSSEL PRINCIPAL DE OFERTAS
    // O próximo anúncio entra pela direita e o atual sai pela esquerda.
    const bannerTrack = document.getElementById("bannerTrack");
    const bannerDots = document.querySelectorAll("#bannerDots button");
    const bannerPrev = document.querySelector(".banner-prev");
    const bannerNext = document.querySelector(".banner-next");
    const bannerSlides = document.querySelectorAll(".banner-slide");
    let bannerAtual = 0;
    let bannerTimer;

    function mostrarBanner(indice) {
        if (!bannerTrack || !bannerSlides.length) return;

        bannerAtual = (indice + bannerSlides.length) % bannerSlides.length;
        bannerTrack.style.transform = `translateX(-${bannerAtual * 25}%)`;

        bannerDots.forEach(function (dot, i) {
            dot.classList.toggle("active", i === bannerAtual);
            dot.setAttribute("aria-current", i === bannerAtual ? "true" : "false");
        });
    }

    function proximoBanner() {
        mostrarBanner(bannerAtual + 1);
    }

    function anteriorBanner() {
        mostrarBanner(bannerAtual - 1);
    }

    function iniciarTimerBanner() {
        clearInterval(bannerTimer);
        bannerTimer = setInterval(proximoBanner, 5000);
    }

    if (bannerTrack && bannerSlides.length) {
        bannerNext?.addEventListener("click", function () {
            proximoBanner();
            iniciarTimerBanner();
        });

        bannerPrev?.addEventListener("click", function () {
            anteriorBanner();
            iniciarTimerBanner();
        });

        bannerDots.forEach(function (dot, indice) {
            dot.addEventListener("click", function () {
                mostrarBanner(indice);
                iniciarTimerBanner();
            });
        });

        iniciarTimerBanner();
    }

});
